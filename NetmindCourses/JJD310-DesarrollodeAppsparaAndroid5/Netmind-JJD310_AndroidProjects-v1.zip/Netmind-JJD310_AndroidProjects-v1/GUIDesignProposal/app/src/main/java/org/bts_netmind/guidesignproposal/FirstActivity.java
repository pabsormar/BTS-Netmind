package org.bts_netmind.guidesignproposal;

import android.app.Activity;
import android.os.Bundle;

public class FirstActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
    }
}
